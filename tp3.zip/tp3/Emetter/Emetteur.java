import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class Emetteur {
    public static void main(String[] args) throws IOException {
        String filePath = "/home/leda/Desktop/tp3/Emetter/file.txt";
        File file = new File(filePath);
        FileInputStream fileInputStream = new FileInputStream(file);

        // Création d'un socket multicast
        InetAddress group = InetAddress.getByName("230.0.0.1");
        MulticastSocket multicastSocket = new MulticastSocket();

        byte[] buffer = new byte[1024];
        int bytesRead;

        while ((bytesRead = fileInputStream.read(buffer)) != -1) {
            // Création d'un paquet à envoyer au groupe multicast
            DatagramPacket packet = new DatagramPacket(buffer, bytesRead, group, 12345);
            multicastSocket.send(packet);
        }

        fileInputStream.close();
        multicastSocket.close();
        System.out.println("Fichier envoyé avec succès.");
    }
}