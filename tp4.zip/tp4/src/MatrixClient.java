
import java.rmi.Naming;
import java.util.Random;

public class MatrixClient {
    public static void main(String[] args) {
        try {
            MatrixServer server = (MatrixServer) Naming.lookup("rmi://localhost/MatrixServer");
            Utilisateur utilisateur = new Utilisateur("user1", "password");
            boolean authenticated = server.authenticate(utilisateur);
            if (!authenticated) {
                System.out.println("Authentication failed");
                return;
            }
            double[][] a = generateMatrix(3, 3);
            double[][] b = generateMatrix(3, 3);
            double[][] result = server.add(a, b);
            System.out.println("Matrix A:");
            displayMatrix(a);
            System.out.println("Matrix B:");
            displayMatrix(b);
            System.out.println("Result:");
            displayMatrix(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static double[][] generateMatrix(int rows, int cols) {
        double[][] matrix = new double[rows][cols];
        Random rand = new Random();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = rand.nextDouble();
            }
        }
        return matrix;
    }

    public static void displayMatrix(double[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                System.out.printf("%.2f ", matrix[i][j]);
            }
            System.out.println();
        }
    }
}