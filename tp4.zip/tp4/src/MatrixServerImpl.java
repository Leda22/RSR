import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;

public class MatrixServerImpl extends UnicastRemoteObject implements MatrixServer {
    private HashMap<String, String> clients;

    public MatrixServerImpl() throws RemoteException {
        clients = new HashMap<String, String>();
    }

    public boolean authenticate(Utilisateur utilisateur) throws RemoteException {
        String password = clients.get(utilisateur.id);
        if (password == null) {
            clients.put((String) utilisateur.id, utilisateur.pass);
            return true;
        } else if (!password.equals(utilisateur.pass)) {
            return false;
        } else {
            return true;
        }
    }

    public double[][] add(double[][] a, double[][] b) throws RemoteException {
        // implementation for matrix addition
    }

    public double[][] multiply(double[][] a, double[][] b) throws RemoteException {
        // implementation for matrix multiplication
    }

    public double[][] subtract(double[][] a, double[][] b) throws RemoteException {
        // implementation for matrix subtraction
    }
}
