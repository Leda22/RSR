import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Stock extends UnicastRemoteObject implements StockInterface {
    private Map<String, Integer> products;
    private List<ClientInterface> clients;

    public Stock() throws RemoteException {
        super();
        products = new HashMap<>();
        clients = new ArrayList<>();
    }

    // Consultation du stock
    public synchronized int getQuantity(String productName) throws RemoteException {
        if (!products.containsKey(productName)) {
            return 0;
        }
        return products.get(productName);
    }

    public synchronized String[] getProductList() throws RemoteException {
        return products.keySet().toArray(new String[0]);
    }

    // Modification du stock
    public synchronized void addProduct(String productName, int quantity) throws RemoteException {
        int currentQuantity = getQuantity(productName);
        products.put(productName, currentQuantity + quantity);
        alertAllClients(productName + " a été ajouté. Quantité totale: " + getQuantity(productName));
    }

    public synchronized void removeProduct(String productName, int quantity) throws RemoteException {
        int currentQuantity = getQuantity(productName);
        if (currentQuantity < quantity) {
            throw new RemoteException("La quantité demandée est supérieure à la quantité en stock.");
        }
        products.put(productName, currentQuantity - quantity);
        alertAllClients(productName + " a été retiré. Quantité totale: " + getQuantity(productName));
    }

    // Enregistrement de callback
    public synchronized void register(ClientInterface client) throws RemoteException {
        clients.add(client);
    }

    public synchronized void unregister(ClientInterface client) throws RemoteException {
        clients.remove(client);
    }

    private synchronized void alertAllClients(String message) throws RemoteException {
        for (ClientInterface client : clients) {
            client.alert(message);
        }
    }
}