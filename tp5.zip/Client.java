import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

public class Client extends UnicastRemoteObject implements ClientInterface {
    private StockInterface stock;

    public Client(StockInterface stock) throws RemoteException {
        super();
        this.stock = stock;
        stock.register(this);
    }

    public void alert(String message) throws RemoteException {
        System.out.println(message);
    }

    public static void main(String[] args) throws Exception {
        StockInterface stock = (StockInterface) Naming.lookup("//localhost/Stock");

        Client client = new Client(stock);
        System.out.println("Client enregistré avec succès auprès du serveur.");

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Veuillez entrer une commande (q pour quitter):");
            String command = scanner.nextLine();
            if (command.equals("q")) {
                break;
            }

            String[] tokens = command.split(" ");
            if (tokens.length != 3) {
                System.out.println("Commande invalide. Exemple: addProduct nomProduit quantite");
                continue;
            }

            String action = tokens[0];
            String productName = tokens[1];
            int quantity = Integer.parseInt(tokens[2]);

            try {
                switch (action) {
                    case "getQuantity":
                        System.out.println(stock.getQuantity(productName));
                        break;
                    case "getProductList":
                        String[] productList = stock.getProductList();
                        for (String product : productList) {
                            System.out.println(product + ": " + stock.getQuantity(product));
                        }
                        break;
                    case "addProduct":
                        stock.addProduct(productName, quantity);
                        break;
                    case "removeProduct":
                        stock.removeProduct(productName, quantity);
                        break;
                    default:
                        System.out.println("Commande invalide. Exemple: addProduct nomProduit quantite");
                        break;
                }
            } catch (RemoteException e) {
                System.out.println("Erreur: " + e.getMessage());
            }
        }

        stock.unregister(client);
        System.out.println("Client retiré avec succès du serveur.");
    }
}

           