import java.rmi.Remote;
import java.rmi.RemoteException;

public interface StockInterface extends Remote {
    int getQuantity(String productName) throws RemoteException;
    String[] getProductList() throws RemoteException;

    void addProduct(String productName, int quantity) throws RemoteException;
    void removeProduct(String productName, int quantity) throws RemoteException;

    // Enregistrement de callback
    void register(ClientInterface client) throws RemoteException;
    void unregister(ClientInterface client) throws RemoteException;
}