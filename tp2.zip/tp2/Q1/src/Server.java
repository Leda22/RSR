import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(7777);
        } catch (IOException e) {
            System.err.println("Could not listen on port: 7777.");
            System.exit(1);
        }

        Socket clientSocket = null;
        System.out.println("Waiting for client on port 7777...");
        try {
            clientSocket = serverSocket.accept();
        } catch (IOException e) {
            System.err.println("Accept failed.");
            System.exit(1);
        }

        System.out.println("Connection successful");
        System.out.println("Waiting for input.....");

        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(),
                true);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
        String inputLine;
        int[][] matrix1;
        int[][] matrix2;
        int[][] result;
        int choice;
        while ((inputLine = in.readLine()) != null) {
            String[] input = inputLine.split(" ");
            choice = Integer.parseInt(input[0]);
            switch (choice) {
                case 1:
                    matrix1 = convertStringToMatrix(input[1]);
                    matrix2 = convertStringToMatrix(input[2]);
                    result = addMatrix(matrix1, matrix2);
                    out.println(convertMatrixToString(result));
                    break;
                case 2:
                    matrix1 = convertStringToMatrix(input[1]);
                    matrix2 = convertStringToMatrix(input[2]);
                    result = subtractMatrix(matrix1, matrix2);
                    out.println(convertMatrixToString(result));
                    break;
                case 3:
                    matrix1 = convertStringToMatrix(input[1]);
                    matrix2 = convertStringToMatrix(input[2]);
                    result = multiplyMatrix(matrix1, matrix2);
                    out.println(convertMatrixToString(result));
                    break;
                default:
                    out.println("Invalid input");
            }
            out.flush();
        }

        out.close();
        in.close();
        clientSocket.close();
        serverSocket.close();
    }

    public static int[][] convertStringToMatrix(String s) {
        String[] rows = s.split(";");
        int[][] matrix = new int[rows.length][];
        for (int i = 0; i < rows.length; i++) {
            String[] rowElements = rows[i].split(",");
            matrix[i] = new int[rowElements.length];
            for (int j = 0; j < rowElements.length; j++) {
                matrix[i][j] = Integer.parseInt(rowElements[j]);
            }
        }
        return matrix;
    }

    public static int[][] addMatrix(int[][] matrix1, int[][] matrix2) {
        int[][] result = new int[matrix1.length][matrix1[0].length];
        for (int i = 0; i < matrix1.length; i++) {
            for (int j = 0; j < matrix1[i].length; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }
        return result;
    }

    public static int[][] subtractMatrix(int[][] matrix1, int[][] matrix2) {
        int[][] result = new int[matrix1.length][matrix1[0].length];
        for (int i = 0; i < matrix1.length; i++) {
            for (int j = 0; j < matrix1[i].length; j++) {
                result[i][j] = matrix1[i][j] - matrix2[i][j];
            }
        }
        return result;
    }

    public static int[][] multiplyMatrix(int[][] matrix1, int[][] matrix2) {
        int[][] result = new int[matrix1.length][matrix2[0].length];
        for (int i = 0; i < matrix1.length; i++) {
            for (int j = 0; j < matrix2[0].length; j++) {
                for (int k = 0; k < matrix1[0].length; k++) {
                    result[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }
        return result;
    }

    public static String convertMatrixToString(int[][] matrix) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                sb.append(matrix[i][j]);
                if (j < matrix[i].length - 1) {
                    sb.append(",");
                }
            }
            if (i < matrix.length - 1) {
                sb.append(";");
            }
        }
        return sb.toString();
    }
}