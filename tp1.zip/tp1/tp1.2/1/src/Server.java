import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        // Creating a server socket with port number 1234
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Server started at IP address: " + serverSocket.getInetAddress().getHostAddress() + " and port: " + serverSocket.getLocalPort());

        // Accepting a connection from the client
        Socket socket = serverSocket.accept();
        System.out.println("Accepted connection from client at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

        // Creating a DataInputStream to read the strings from the client
        DataInputStream in = new DataInputStream(socket.getInputStream());
        
        // Creating a DataOutputStream to send the result to the client
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());

        // Reading the strings from the client
        String string1 = in.readUTF();
        String string2 = in.readUTF();
        System.out.println("Received string1: " + string1 + " and string2: " + string2);
        
        // Checking if string2 is included in string1
        boolean result = string1.contains(string2);
        
        // Sending the result to the client
        out.writeBoolean(result);
        System.out.println("Sent result: " + result);

        // Closing the input stream
        in.close();
        // Closing the output stream
        out.close();
        // Closing the socket
        socket.close();
        // Closing the server socket
        serverSocket.close();
    }
}
//No, it's not necessary to use flush() with DataOutputStream or PrintWriter 
//when writing to a socket's output stream. When you call write() or writeUTF() methods, 
//the data is first stored in a buffer before being sent to the output stream. However, 
//if you need to ensure that the data is immediately sent to the output stream, 
//you can call flush() to clear the buffer and force the data to be sent immediately.