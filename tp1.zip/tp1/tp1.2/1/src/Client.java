import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        // Creating a socket to connect to the server at IP address "localhost" and port number 1234
        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

        // Creating a Scanner to read input from the user
        Scanner scanner = new Scanner(System.in);
        
        // Creating a DataOutputStream to send the strings to the server
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());

        // Reading the two strings from the user
        System.out.print("Enter string1: ");
        String string1 = scanner.nextLine();
        System.out.print("Enter string2: ");
        String string2 = scanner.nextLine();
        
        // Sending the two strings to the server
        out.writeUTF(string1);
        out.writeUTF(string2);

        // Creating a DataInputStream to read the result from the server
        DataInputStream in = new DataInputStream(socket.getInputStream());

        // Reading the result from the server
        boolean result = in.readBoolean();
        System.out.println("Result received from server: " + result);

        // Closing the input stream
        in.close();
        // Closing the output stream
        out.close();
        // Closing the socket
        socket.close();
    }
}
//No, it's not necessary to use flush() with DataOutputStream or PrintWriter 
//when writing to a socket's output stream. When you call write() or writeUTF() methods, 
//the data is first stored in a buffer before being sent to the output stream. However, 
//if you need to ensure that the data is immediately sent to the output stream, 
//you can call flush() to clear the buffer and force the data to be sent immediately.