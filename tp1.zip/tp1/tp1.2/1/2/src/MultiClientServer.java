import java.io.*;
import java.net.*;

public class MultiClientServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server started. Listening on port 5000...");

        while (true) {
            Socket clientSocket = serverSocket.accept(); // Wait for a new client connection

            // Start a new thread to handle the connection
            Thread clientThread = new Thread(new ClientHandler(clientSocket));
            clientThread.start();
        }
    }

    // A separate class to handle each client connection in a new thread
    private static class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                // Creating an ObjectInputStream to receive the strings from the client
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

                // Reading the two strings from the client
                String string1 = (String) in.readObject();
                String string2 = (String) in.readObject();

                // Checking if string2 is contained in string1
                boolean result = string1.contains(string2);

                // Creating an ObjectOutputStream to send the result back to the client
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

                // Sending the result back to the client
                out.writeBoolean(result);
                out.flush();

                // Closing the streams and the socket
                out.close();
                in.close();
                socket.close();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
//Yes, it's still necessary to call flush() after writing to the ObjectOutputStream 
//in the client code and after writing to the ObjectOutputStream in the server code. 
//The flush() method is used to flush the output buffer of the stream, which means that 
//any data remaining in the buffer is sent to the destination.