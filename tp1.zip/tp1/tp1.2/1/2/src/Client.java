import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // Creating a socket to connect to the server at IP address "localhost" and port number 1234
        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

        // Creating a Scanner to read input from the user
        Scanner scanner = new Scanner(System.in);
        
        // Creating an ObjectOutputStream to send the strings to the server
        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

        // Reading the two strings from the user
        System.out.print("Enter string1: ");
        String string1 = scanner.nextLine();
        System.out.print("Enter string2: ");
        String string2 = scanner.nextLine();
        
        // Sending the two strings to the server
        out.writeObject(string1);
        out.writeObject(string2);
        out.flush();

        // Creating an ObjectInputStream to read the result from the server
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

        // Reading the result from the server
        boolean result = in.readBoolean();
        System.out.println("Result received from server: " + result);

        // Closing the input stream
        in.close();
        
        // Closing the output stream
        out.close();
        
        // Closing the socket
        socket.close();
    }
}
//Yes, it's still necessary to call flush() after writing to the ObjectOutputStream 
//in the client code and after writing to the ObjectOutputStream in the server code. 
//The flush() method is used to flush the output buffer of the stream, which means that 
//any data remaining in the buffer is sent to the destination.
