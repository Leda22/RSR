import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // Creating a server socket at port number 1234
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Server listening on port " + serverSocket.getLocalPort() + "...");

        while (true) {
            // Waiting for a client to connect
            Socket socket = serverSocket.accept();
            System.out.println("Client connected from IP address " + socket.getInetAddress().getHostAddress() + " and port " + socket.getPort());

            // Creating an ObjectInputStream to read the strings from the client
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            // Reading the two strings from the client
            String string1 = (String) in.readObject();
            String string2 = (String) in.readObject();

            // Checking if string2 is included in string1
            boolean result = string1.contains(string2);
            System.out.println("Result: " + result);

            // Creating an ObjectOutputStream to send the result back to the client
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

            // Sending the result back to the client
            out.writeBoolean(result);
            out.flush();

            // Closing the input stream
            in.close();
            
            // Closing the output stream
            out.close();
            
            // Closing the socket
            socket.close();
        }
    }
}
//Yes, it's still necessary to call flush() after writing to the ObjectOutputStream 
//in the client code and after writing to the ObjectOutputStream in the server code. 
//The flush() method is used to flush the output buffer of the stream, which means that 
//any data remaining in the buffer is sent to the destination.