import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static int numClients = 0;
    private static List<Socket> sockets = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(1234);
        System.out.println("Server started at IP address: " + InetAddress.getLocalHost().getHostAddress() + " and port: " + server.getLocalPort());

        while (true) {
            Socket socket = server.accept();
            sockets.add(socket);
            numClients++;
            System.out.println("Client connected from IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort() + " (total clients: " + numClients + ")");

            Thread t = new Thread(() -> {
                try {
                    DataInputStream in = new DataInputStream(socket.getInputStream());
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());

                    out.writeInt(numClients);

                    String string1 = in.readUTF();
                    String string2 = in.readUTF();
                    System.out.println("Received string1: " + string1 + " and string2: " + string2 + " from client at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

                    boolean result = string1.contains(string2);
                    out.writeBoolean(result);
                    System.out.println("Sent result: " + result + " to client at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

                    in.close();
                    out.close();
                    socket.close();

                    sockets.remove(socket);
                    numClients--;
                    System.out.println("Client disconnected from IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort() + " (total clients: " + numClients + ")");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            t.start();
        }
    }
}
