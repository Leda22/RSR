import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter string1: ");
        String string1 = scanner.nextLine();
        System.out.print("Enter string2: ");
        String string2 = scanner.nextLine();

        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());
        System.out.println("Client IP address: " + InetAddress.getLocalHost().getHostAddress() + " and port: " + socket.getLocalPort());

        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        DataInputStream in = new DataInputStream(socket.getInputStream());

        out.writeUTF(string1);
        out.writeUTF(string2);
        System.out.println("Sent string1: " + string1 + " and string2: " + string2);
        boolean result = in.readBoolean();
        System.out.println("Received result: " + result);

        out.close();
        in.close();
        socket.close();
    }
}
