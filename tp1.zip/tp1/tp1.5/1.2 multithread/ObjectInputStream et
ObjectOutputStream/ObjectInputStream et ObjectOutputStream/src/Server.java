import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static List<ClientHandler> clients = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(1234);
        System.out.println("Server started at IP address: " + InetAddress.getLocalHost().getHostAddress() + " and port: " + server.getLocalPort());

        while (true) {
            Socket socket = server.accept();
            System.out.println("Client connected from IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

            ClientHandler client = new ClientHandler(socket);
            clients.add(client);
            client.start();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private ObjectOutputStream out;
        private ObjectInputStream in;

        public ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            this.out = new ObjectOutputStream(socket.getOutputStream());
            this.in = new ObjectInputStream(socket.getInputStream());
        }

        @Override
        public void run() {
            try {
                while (true) {
                    String string1 = in.readUTF();
                    String string2 = in.readUTF();
                    System.out.println("Received string1: " + string1 + " and string2: " + string2);
                    boolean result = string1.contains(string2);
                    out.writeBoolean(result);
                    out.flush();
                    System.out.println("Sent result: " + result);

                    int numClients = clients.size();
                    out.writeInt(numClients);
                    out.flush();
                    System.out.println("Sent number of clients: " + numClients);
                }
            } catch (IOException e) {
                System.out.println("Client disconnected");
            } finally {
                try {
                    out.close();
                    in.close();
                    socket.close();
                    clients.remove(this);
                    System.out.println("Number of connected clients: " + clients.size());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
