import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter string1: ");
        String string1 = scanner.nextLine();
        System.out.print("Enter string2: ");
        String string2 = scanner.nextLine();

        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());
        System.out.println("Client IP address: " + InetAddress.getLocalHost().getHostAddress() + " and port: " + socket.getLocalPort());

        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

        out.writeUTF(string1);
        out.writeUTF(string2);
        out.flush();
        System.out.println("Sent string1: " + string1 + " and string2: " + string2);
        boolean result = in.readBoolean();
        System.out.println("Received result: " + result);

        int numClients = in.readInt();
        System.out.println("Number of connected clients: " + numClients);
        
        in.close();
        out.close();
        socket.close();
    }
}
