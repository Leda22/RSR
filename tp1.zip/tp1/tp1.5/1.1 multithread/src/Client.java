import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the IP address of the server to connect to
        System.out.print("Enter server IP address: ");
        String serverAddress = scanner.nextLine();

        // Create a new Socket object and connect to the server at the specified IP address and port 1234
        Socket socket = new Socket(serverAddress, 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + ", port: " + socket.getPort());

        // Create a BufferedReader and PrintWriter to communicate with the server
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Read the number of connected clients from the server and display it
        String clientCount = in.readLine();
        System.out.println(clientCount);

        while (true) {
            // Prompt the user to enter two strings
            System.out.print("Enter string 1: ");
            String string1 = scanner.nextLine();
            System.out.print("Enter string 2: ");
            String string2 = scanner.nextLine();

            // Send the two strings to the server
            out.println(string1);
            out.println(string2);

            // Read the server's response and display it
            boolean result = Boolean.parseBoolean(in.readLine());
            System.out.println("String 2 is contained in string 1: " + result);
        }
    }
}
