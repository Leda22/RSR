import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;

public class Server {
    // Counter for the number of connected clients, AtomicInteger is used for thread safety
    private static final AtomicInteger clientCount = new AtomicInteger(0);

    public static void main(String[] args) throws IOException {
        // Create a new ServerSocket object that listens for incoming connections on port 1234
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Server started");

        while (true) {
            // Wait for a client to connect and accept the connection
            Socket clientSocket = serverSocket.accept();
            // Increment the client count and assign the current value as the client ID
            int clientId = clientCount.incrementAndGet();
            System.out.println("New client connected, client ID: " + clientId);

            // Create a new thread to handle communication with the client
            ClientHandler clientHandler = new ClientHandler(clientSocket, clientId);
            clientHandler.start();
        }
    }

    // Inner class to handle communication with a single client
    private static class ClientHandler extends Thread {
        private final Socket clientSocket;
        private final int clientId;

        public ClientHandler(Socket clientSocket, int clientId) {
            this.clientSocket = clientSocket;
            this.clientId = clientId;
        }

        @Override
        public void run() {
            try {
                // Create a BufferedReader and PrintWriter to communicate with the client
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                // Send the number of connected clients to the new client
                out.println("Number of connected clients: " + clientCount.get());

                while (true) {
                    // Read two strings from the client
                    String string1 = in.readLine();
                    String string2 = in.readLine();

                    // If either string is null, it means the client has disconnected, so break out of the loop
                    if (string1 == null || string2 == null) {
                        break;
                    }

                    // Check if string2 is contained in string1 and send the result to the client
                    boolean result = string1.contains(string2);
                    out.println(result);
                }

                // Client has disconnected, close the BufferedReader, PrintWriter, and Socket
                System.out.println("Client disconnected, client ID: " + clientId);
                in.close();
                out.close();
                clientSocket.close();
                // Decrement the client count
                clientCount.decrementAndGet();
            } catch (IOException e) {
                // Print an error message if there's an error communicating with the client
                System.out.println("Error handling client, client ID: " + clientId + ", message: " + e.getMessage());
            }
        }
    }
}
