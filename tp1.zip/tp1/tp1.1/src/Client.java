import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        // Creating a socket to connect to the server at IP address "localhost" and port number 1234
        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to server at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

        // Creating a Scanner to read input from the user
        Scanner scanner = new Scanner(System.in);
        
        // Creating a PrintWriter to send the strings to the server
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Reading the two strings from the user
        System.out.print("Enter string1: ");
        String string1 = scanner.nextLine();
        System.out.print("Enter string2: ");
        String string2 = scanner.nextLine();
        
        // Sending the two strings to the server
        out.println(string1);
        out.println(string2);
        
        // Creating a Scanner to read the result from the server
        Scanner in = new Scanner(socket.getInputStream());
        
        // Reading the result from the server
        boolean result = in.nextBoolean();
        System.out.println("Result from server: " + result);

        // Closing the input stream
        in.close();
        // Closing the output stream
        out.close();
        // Closing the socket
        socket.close();
    }
}
//It's not necessary to use the flush() method in this code, 
//as we've set the autoFlush parameter in the PrintWriter constructor to true. 