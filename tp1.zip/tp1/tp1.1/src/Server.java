import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws IOException {
        // Creating a server socket with port number 1234
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Server started at IP address: " + serverSocket.getInetAddress().getHostAddress() + " and port: " + serverSocket.getLocalPort());

        // Accepting a connection from the client
        Socket socket = serverSocket.accept();
        System.out.println("Accepted connection from client at IP address: " + socket.getInetAddress().getHostAddress() + " and port: " + socket.getPort());

        // Creating a Scanner to read the strings from the client
        Scanner scanner = new Scanner(socket.getInputStream());
        
        // Creating a PrintWriter to send the result to the client
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Reading the strings from the client
        String string1 = scanner.nextLine();
        String string2 = scanner.nextLine();
        System.out.println("Received string1: " + string1 + " and string2: " + string2);
        
        // Checking if string2 is included in string1
        boolean result = string1.contains(string2);
        
        // Sending the result to the client
        out.println(result);
        System.out.println("Sent result: " + result);

        // Closing the input stream
        scanner.close();
        
        // Closing the output stream
        out.close();
        
        // Closing the socket
        socket.close();
        
        // Closing the server socket
        serverSocket.close();
    }
}
//It's not necessary to use the flush() method in this code, 
//as we've set the autoFlush parameter in the PrintWriter constructor to true. 